# YouTube → MP3 Extractor

## Description
Application graphique moderne pour GNOME permettant de télécharger des vidéos YouTube et de les convertir automatiquement en MP3. Cette application utilise GTK4 et libadwaita pour une intégration parfaite avec GNOME.

## Fonctionnalités
- Interface graphique moderne GTK4
- Téléchargements multiples en parallèle
- Barre de progression en temps réel
- Conversion automatique en MP3
- Gestion des erreurs
- Qualité audio 192kbps

## Prérequis
- Python 3.6+
- GTK 4.0
- libadwaita 1.0
- ffmpeg (pour la conversion audio)

## Installation

### 1. Installation des dépendances système
```bash
# Installation des paquets nécessaires
sudo apt install python3-venv ffmpeg
sudo apt install libgirepository1.0-dev gcc libcairo2-dev pkg-config python3-dev gir1.2-gtk-4.0 gir1.2-adw-1
```

### 2. Installation de l'application
```bash
# Cloner ou télécharger le dépôt
cd /chemin/vers/le/dossier

# Rendre le script d'installation exécutable
chmod +x install.sh

# Lancer l'installation
./install.sh
```

L'installation se fait entièrement dans votre dossier personnel :
- Application : `~/.local/share/youtube-extractor/`
- Exécutable : `~/.local/bin/youtube_extractor`
- Raccourci : `~/.local/share/applications/youtube-extractor.desktop`

## Utilisation

### 1. Préparation des URLs
Créez un fichier `urls.txt` contenant les URLs YouTube à télécharger (une par ligne) :
```
https://www.youtube.com/watch?v=example1
https://www.youtube.com/watch?v=example2
```

### 2. Lancement de l'application
Deux méthodes au choix :
- Via le menu des applications (cherchez "YouTube → MP3")
- En ligne de commande : `youtube_extractor`

### 3. Téléchargement
1. Cliquez sur "Démarrer"
2. L'application va :
   - Lire le fichier urls.txt
   - Afficher une barre de progression pour chaque vidéo
   - Télécharger et convertir en parallèle
   - Sauvegarder les MP3 dans `~/Musique/Youtube/`

## Structure des fichiers
```
~/Musique/Youtube/     # Dossier de destination des MP3
urls.txt              # Liste des URLs à télécharger
```

## Dépannage

### Problèmes courants
1. **L'application ne démarre pas**
   - Vérifiez que l'environnement virtuel est activé
   - Vérifiez les dépendances système

2. **Erreur de module manquant**
   ```bash
   source ~/.local/share/youtube-extractor/venv/bin/activate
   pip install --upgrade yt-dlp PyGObject
   ```

3. **Erreur de conversion**
   - Vérifiez que ffmpeg est installé
   - Vérifiez les permissions du dossier de destination

4. **URLs non valides**
   - Vérifiez le format des URLs dans urls.txt
   - Vérifiez que les vidéos sont disponibles

## Désinstallation
Pour supprimer l'application :
```bash
rm -rf ~/.local/share/youtube-extractor
rm ~/.local/bin/youtube_extractor
rm ~/.local/share/applications/youtube-extractor.desktop
```

## Mise à jour
Pour mettre à jour yt-dlp (recommandé régulièrement) :
```bash
source ~/.local/share/youtube-extractor/venv/bin/activate
pip install --upgrade yt-dlp
```

## Sécurité
- Installation sans droits root
- Environnement virtuel isolé
- Pas de modification système

## Contribution
Les contributions sont les bienvenues :
- Signalement de bugs
- Suggestions d'améliorations
- Pull requests

## Licence
Ce logiciel est fourni sous licence libre. Vous êtes libre de le modifier et de le redistribuer selon vos besoins. 