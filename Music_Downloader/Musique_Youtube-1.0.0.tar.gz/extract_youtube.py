#!/usr/bin/env python3

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib
import os
import threading
import queue
import subprocess
from dataclasses import dataclass

@dataclass
class DownloadProgress:
    url: str
    title: str
    progress: float
    status: str
    error: str = ""
    completed: bool = False

class YouTubeDownloader(Gtk.Window):
    def __init__(self):
        super().__init__(title="YouTube Music Downloader")
        self.set_default_size(600, 400)
        
        self.output_dir = os.path.expanduser("~/Musique/YouTube")
        self.progress_queue = queue.Queue()
        self.downloader = None
        
        # Créer le répertoire de sortie s'il n'existe pas
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Box principale verticale
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        self.add(main_box)

        # Label pour le dossier de destination
        dest_label = Gtk.Label()
        dest_label.set_text(f"Les fichiers seront téléchargés dans : {self.output_dir}")
        dest_label.set_line_wrap(True)
        dest_label.set_xalign(0)
        main_box.pack_start(dest_label, False, True, 0)

        # Zone de texte pour les URLs
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        self.url_text = Gtk.TextView()
        self.url_text.set_wrap_mode(Gtk.WrapMode.WORD)
        scrolled.add(self.url_text)
        main_box.pack_start(scrolled, True, True, 0)

        # Boutons
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        button_box.set_halign(Gtk.Align.CENTER)

        # Bouton pour charger urls.txt
        load_button = Gtk.Button(label="Charger urls.txt")
        load_button.connect("clicked", self.load_urls)
        button_box.pack_start(load_button, True, True, 0)

        # Bouton de téléchargement
        self.download_button = Gtk.Button(label="Télécharger")
        self.download_button.connect("clicked", self.start_download)
        button_box.pack_start(self.download_button, True, True, 0)

        # Bouton Quitter
        quit_button = Gtk.Button(label="Quitter")
        quit_button.connect("clicked", self.quit_app)
        button_box.pack_start(quit_button, True, True, 0)

        main_box.pack_start(button_box, False, True, 0)

        # Zone de progression
        scrolled_progress = Gtk.ScrolledWindow()
        scrolled_progress.set_vexpand(True)
        self.progress_text = Gtk.TextView()
        self.progress_text.set_editable(False)
        self.progress_text.set_wrap_mode(Gtk.WrapMode.WORD)
        scrolled_progress.add(self.progress_text)
        main_box.pack_start(scrolled_progress, True, True, 0)

        self.connect("destroy", Gtk.main_quit)
        GLib.timeout_add(100, self.check_progress)

    def load_urls(self, button):
        dialog = Gtk.FileChooserDialog(
            title="Choisir le fichier urls.txt",
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            "Annuler", Gtk.ResponseType.CANCEL,
            "Ouvrir", Gtk.ResponseType.OK
        )

        filter_txt = Gtk.FileFilter()
        filter_txt.set_name("Fichiers texte")
        filter_txt.add_pattern("*.txt")
        dialog.add_filter(filter_txt)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            file_path = dialog.get_filename()
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                    buffer = self.url_text.get_buffer()
                    buffer.set_text(content)
            except Exception as e:
                self.show_error(f"Erreur lors de la lecture du fichier : {str(e)}")
        dialog.destroy()

    def show_error(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def show_info(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def quit_app(self, button):
        if self.downloader and self.downloader.is_alive():
            dialog = Gtk.MessageDialog(
                transient_for=self,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text="Des téléchargements sont en cours. Voulez-vous vraiment quitter ?"
            )
            response = dialog.run()
            dialog.destroy()
            if response == Gtk.ResponseType.YES:
                Gtk.main_quit()
        else:
            Gtk.main_quit()

    def append_progress_text(self, text):
        buffer = self.progress_text.get_buffer()
        end_iter = buffer.get_end_iter()
        buffer.insert(end_iter, text + "\n")
        # Faire défiler jusqu'en bas
        adj = self.progress_text.get_vadjustment()
        adj.set_value(adj.get_upper() - adj.get_page_size())

    def start_download(self, button):
        buffer = self.url_text.get_buffer()
        start_iter = buffer.get_start_iter()
        end_iter = buffer.get_end_iter()
        text = buffer.get_text(start_iter, end_iter, False)
        
        urls = [url.strip() for url in text.split('\n') if url.strip()]
        
        if not urls:
            self.show_error("Veuillez entrer au moins une URL YouTube.")
            return
            
        self.download_button.set_sensitive(False)
        self.progress_text.get_buffer().set_text("")
        
        def download_thread():
            for url in urls:
                self.download_url(url)
            GLib.idle_add(self.download_completed)
            
        self.downloader = threading.Thread(target=download_thread)
        self.downloader.start()

    def download_completed(self):
        self.download_button.set_sensitive(True)
        self.show_info("Tous les téléchargements sont terminés !")

    def download_url(self, url: str):
        """Télécharge une URL YouTube"""
        try:
            # Vérifier si c'est une playlist
            is_playlist = 'list=' in url
            
            if is_playlist:
                # Notification de démarrage pour la playlist
                GLib.idle_add(self.append_progress_text, f"Démarrage du téléchargement de la playlist...")
                
                cmd = [
                    'yt-dlp',
                    '-x',                    # Extraire l'audio
                    '--audio-format', 'mp3', # Format MP3
                    '--audio-quality', '0',  # Meilleure qualité
                    '--yes-playlist',        # Confirmer le téléchargement de la playlist
                    '-o', f'{self.output_dir}/%(title)s.%(ext)s',
                    url
                ]
            else:
                # Obtenir le titre de la vidéo unique
                cmd_title = ['yt-dlp', '--get-title', url]
                process_title = subprocess.run(cmd_title, capture_output=True, text=True)
                
                if process_title.returncode != 0:
                    raise Exception("Impossible d'obtenir le titre de la vidéo")
                    
                title = process_title.stdout.strip()
                GLib.idle_add(self.append_progress_text, f"Démarrage du téléchargement de : {title}")
                
                cmd = [
                    'yt-dlp',
                    '-x',                    # Extraire l'audio
                    '--audio-format', 'mp3', # Format MP3
                    '--audio-quality', '0',  # Meilleure qualité
                    '--no-playlist',         # Ne pas télécharger la playlist si c'est une vidéo unique
                    '-o', f'{self.output_dir}/%(title)s.%(ext)s',
                    url
                ]

            process = subprocess.run(cmd, capture_output=True, text=True)

            if process.returncode == 0:
                if is_playlist:
                    GLib.idle_add(self.append_progress_text, f"✓ Téléchargement de la playlist terminé")
                else:
                    GLib.idle_add(self.append_progress_text, f"✓ Téléchargement terminé : {title}")
            else:
                raise Exception(f"Erreur lors du téléchargement: {process.stderr}")

        except Exception as e:
            GLib.idle_add(self.append_progress_text, f"❌ Erreur : {str(e)}")

    def check_progress(self):
        return True

def main():
    win = YouTubeDownloader()
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
